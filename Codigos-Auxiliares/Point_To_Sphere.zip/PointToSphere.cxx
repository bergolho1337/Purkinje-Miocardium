// =====================================================================================================
// Realiza a leitura dos pontos em um arquivo .vtp e gera um outro arquivo .vtp contendo esferas
// centradas nestes pontos.
// =====================================================================================================


#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
 
#include "vtkCellArray.h"
#include "vtkPoints.h"
#include "vtkPointData.h"
#include "vtkXMLPolyDataReader.h"
#include "vtkPolyData.h"
#include <vtkVersion.h>
#include <vtkCellArray.h>
#include <vtkPoints.h>
#include <vtkXMLPolyDataWriter.h>
#include <vtkPolyData.h>
#include <vtkActor.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>
#include <vtkAppendPolyData.h>
#include <vtkFloatArray.h>
#include <vtkPolyDataMapper.h>

struct Point
{
	double x,y,z;
	Point(const double xin, const double yin, const double zin) : x(xin), y(yin), z(zin) {}
};

int main (int argc, char *argv[])
{
    if (argc-1 < 1)
    {
        printf("============================================================\n");
        printf("Usage:> %s <vtp_file_with_points>\n",argv[0]);
        printf("Example: %s errorTerminals.vtp\n",argv[0]);
        printf("============================================================\n");
        exit(1);
    }
    else
    {   
        // Get all data from the file
        vtkXMLPolyDataReader* reader = vtkXMLPolyDataReader::New();
        reader->SetFileName(argv[1]);
        reader->Update();
        vtkPolyData* polydata = reader->GetOutput();
    
        //get the number of points the file contains
        vtkIdType NumPoints = polydata->GetNumberOfPoints();

        //if there are no points, quit
        if(!(NumPoints > 0) )
        {
            exit(-1);
        }
    
        // Read in all of the points
        std::vector<Point> Points;
        double point[3];
        for(vtkIdType i = 0; i < NumPoints; i++)
        {
            polydata->GetPoint(i, point);
            Points.push_back(Point(point[0], point[1], point[2]));
        }
        
        // Get the scalars of all the points
        std::vector<double> Scalars;
        for(int i = 0; i < NumPoints; i++)
        {
            double w = polydata->GetPointData()->GetScalars()->GetComponent(0,i);
            Scalars.push_back(w);
        }

        // Create a sphere for each point
        vtkSmartPointer<vtkAppendPolyData> appendFilter =
            vtkSmartPointer<vtkAppendPolyData>::New();
        for (int i = 0; i < NumPoints; i++)
        {
            vtkSmartPointer<vtkSphereSource> sphereSource = 
                vtkSmartPointer<vtkSphereSource>::New();
            sphereSource->SetCenter(Points[i].x,Points[i].y,Points[i].z);
            sphereSource->SetRadius(1.0);
            sphereSource->Update();

            // Color the points of the sphere with the same scalar of the point
            int numPtsSphere = sphereSource->GetOutput()->GetPoints()->GetNumberOfPoints();
            vtkSmartPointer<vtkFloatArray> scalars =
                vtkSmartPointer<vtkFloatArray>::New();
            scalars->SetNumberOfValues( numPtsSphere );
            for( int j = 0; j < numPtsSphere; j++ )
                scalars->SetValue(j,Scalars[i]);
            sphereSource->GetOutput()->GetPointData()->SetScalars(scalars);
            sphereSource->Update();

            appendFilter->AddInputConnection(sphereSource->GetOutputPort());
            
        }
        appendFilter->Update();

        // Write the file
        vtkSmartPointer<vtkXMLPolyDataWriter> writer =  
            vtkSmartPointer<vtkXMLPolyDataWriter>::New();
        writer->SetFileName("spheres.vtp");
        writer->SetInputConnection(appendFilter->GetOutputPort());
        writer->Write();
            
    }	
    
	return 0;
}
