#include "../include/reader.h"

ReaderVTK* newReaderVTK (int argc, char *argv[])
{
    printf("=============================================================================\n");
    ReaderVTK *reader = (ReaderVTK*)malloc(sizeof(ReaderVTK));
    reader->file = readFile(argv[1]);
    return reader;
}

// Realiza a leitura do arquivo .vtk, e armazena as informacoes em uma estrutura do tipo vtkFile
vtkFile* readFile (char filename[])
{
    printf("[!] Reading file %s ... ",filename);
    fflush(stdout);
    char str[200], str2[200];
    int trash;
    FILE *in = fopen(filename,"r");
    vtkFile *vtk = (vtkFile*)malloc(sizeof(vtkFile));

    // Ler as coordenadas dos pontos
    while (fscanf(in,"%s",str) != EOF)
        if (strcmp(str,"POINTS") == 0) break;
    if (!fscanf(in,"%d",&vtk->N)) errorMsg();
    if (!fscanf(in,"%s",str)) errorMsg();
    for (int i = 0; i < vtk->N; i++)
    {
        Point point;
        if (!fscanf(in,"%lf %lf %lf",&point.x,&point.y,&point.z)) errorMsg();
        vtk->points.push_back(point);
    }
        
    // Ler as linhas
    while (fscanf(in,"%s",str) != EOF)
        if (strcmp(str,"LINES") == 0) break;
    if (!fscanf(in,"%d %d",&vtk->M,&trash)) errorMsg();
    for (int i = 0; i < vtk->M; i++)
    {
        Line line;
        if (!fscanf(in,"%d %d %d",&trash,&line.init,&line.end)) errorMsg();
        vtk->lines.push_back(line);
    }

    // Ler os tempos de ativacao dos pontos
    while (fscanf(in,"%s",str) != EOF)
        if (strcmp(str,"default") == 0) break;
    for (int i = 0; i < vtk->N; i++)
        if (!fscanf(in,"%lf",&vtk->points[i].aTime)) errorMsg();
    fclose(in);

    // Retorna a estrutura montada
    printf("ok\n");

    return vtk;
}

void errorMsg ()
{
    printf("[-] Error found!\n");
    exit(-1);
}

// Verifica se existe algum ponto em que o tempo de ativacao foi muito alto (= INF)
void checkThreshold (vtkFile *vtk, double value)
{
    int N = vtk->N;
    for (int i = 0; i < N; i++)
    {
        // Checar se o ponto nao foi atingido
        if (vtk->points[i].aTime > value)
        {
            // Checar se o ponto com problema esta ligado a alguem na arvore
            // Se nao estiver, entao podemos elimina-lo da arvore
            if (!checkConnectivityTree(vtk,i))
            {
                vtk->points.erase(vtk->points.begin()+i);
                updateLines(vtk,i);
                i--;
            }
        }
    }
}

// Percorre todas as linhas da arvore e atualiza o indice do vertice deletado
void updateLines (vtkFile *vtk, int id)
{
    for (int i = 0; i < vtk->M; i++)
    {
        // Como o vertice 'id' foi removido temos que atualizar o indice para tras no vetor de linhas 
        // pois ficou um 'buraco'
        if (vtk->lines[i].init > id)
            vtk->lines[i].init--;
        if (vtk->lines[i].end > id)
            vtk->lines[i].end--;
    }
}

// Checa se para um determinado ponto com 'id' existe alguma linha contendo o mesmo
// Se existir o ponto pertence a arvore, senao eh ponto isolado
bool checkConnectivityTree (vtkFile *vtk, int id)
{
    int M = vtk->M;
    for (int i = 0; i < M; i++)
    {
        // Se o vertice aparecer em alguma linha eh sinal que se encontra na arvore
        if (id == vtk->lines[i].init || id == vtk->lines[i].end)
            return true;
    }
    return false;
}

void writeVTK (vtkFile *vtk)
{
    FILE *fileVTK = fopen("newTree.vtk","w+");
    fprintf(fileVTK,"# vtk DataFile Version 3.0\n");
    fprintf(fileVTK,"vtk output\n");
    fprintf(fileVTK,"ASCII\n");
    fprintf(fileVTK,"DATASET POLYDATA\n");
    fprintf(fileVTK,"POINTS %d float\n",(int)vtk->points.size());
    for (unsigned int i = 0; i < vtk->points.size(); i++)
        fprintf(fileVTK,"%e %e %e\n",vtk->points[i].x,vtk->points[i].y,vtk->points[i].z);
    fprintf(fileVTK,"LINES %d %d\n",(int)vtk->lines.size(),(int)vtk->lines.size()*3);
    for (unsigned int i = 0; i < vtk->lines.size(); i++)
        fprintf(fileVTK,"2 %d %d\n",vtk->lines[i].init,vtk->lines[i].end);
    fprintf(fileVTK,"POINT_DATA %d\n",(int)vtk->points.size());
    fprintf(fileVTK,"SCALARS FMMTime float\n");
    fprintf(fileVTK,"LOOKUP_TABLE default\n");
    for (unsigned int i = 0; i < vtk->points.size()-130; i++)
        fprintf(fileVTK,"0\n");
    for (unsigned int i = vtk->points.size()-130; i < vtk->points.size(); i++)
        fprintf(fileVTK,"1\n");
    fclose(fileVTK);
}

void writeTerminals (vtkFile *vtk)
{
    FILE *fileTXT = fopen("terminals.txt","w+");
    for (unsigned int i = vtk->points.size()-130; i < vtk->points.size(); i++)
        fprintf(fileTXT,"%d %lf %lf %lf\n",i,vtk->points[i].x,vtk->points[i].y,vtk->points[i].z);
    fclose(fileTXT);
}
