#include <cstdio>
#include <cstdlib>
#include "../include/reader.h"

using namespace std;

int main (int argc, char *argv[])
{
    if (argc-1 < 1)
    {
        printf("===============================================================================\n");
        printf("Usage:> %s <tree.vtk>\n",argv[0]);
        printf("<tree.vtk> = Arquivo .vtk contendo a arvore de Purkinje\n\n");
        printf("Exemplo: %s dijkstra_130.vtk\n",argv[0]);
        printf("===============================================================================\n");
        exit(-1);
    }
    else
    {
        ReaderVTK *reader = newReaderVTK(argc,argv);
        checkThreshold(reader->file,1.0e+10);
        writeVTK(reader->file);
        writeTerminals(reader->file);
        //freeMemory(reader);
        return 0;
    }
}
