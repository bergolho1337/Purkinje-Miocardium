#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>

using namespace std;

struct Point
{
    double x, y, z;                     // Coordenadas (x,y,z)
    double aTime;                       // Tempo de ativacao
}typedef Point;

struct Line
{
    int init;                           // Indice do inicio da linha
    int end;                            // Indice do fim da linha
}typedef Line;

struct vtkFile
{
    int N;                              // Numero de pontos
    int M;                              // Numero de linhas
    vector<Point> points;               // Vetor de pontos do .vtk
    vector<Line> lines;                 // Vetor de linhas do .vtk
}typedef vtkFile;

struct ReaderVTK
{
    vtkFile *file;                      // Estrutura contendo os pontos do arquivo          
}typedef ReaderVTK;

ReaderVTK* newReaderVTK (int argc, char *argv[]);
vtkFile* readFile (char filename[]);
void errorMsg ();
void checkThreshold (vtkFile *vtk, double value);
bool checkConnectivityTree (vtkFile *vtk, int id);
void updateLines (vtkFile *vtk, int id);
void writeVTK (vtkFile *vtk);
void writeTerminals (vtkFile *vtk);