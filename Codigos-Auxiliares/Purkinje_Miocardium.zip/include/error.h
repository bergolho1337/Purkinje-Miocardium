#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

void error (const char *message);